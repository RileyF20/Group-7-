<img width="150" height="150" src="./res/documentation/icon.png" />

# Hangman
[![made-with-Markdown](https://img.shields.io/badge/Made%20with-Flutter-1389FD.svg)](http://flutter.dev)

A hangman game written in Dart with Flutter framework. Player has 5 lives in each turn. Previous scores can be viewed in High Scores page.

## Screenshots
<img src="./res/documentation/hangman_animation.gif" width="240" height="500" />

<img align="center" width="350" src="./res/documentation/pre1.png"   ><img align="center" width="350" src="./res/documentation/pre2.png" hspace="50">

<img align="center" width="350"  src="./res/documentation/pre3.png"   ><img width="350" align="center" src="./res/documentation/pre4.png" hspace="50">


App screenshots created with <a href="https://previewed.app/">Previewed</a>

## License

Released under MIT License. See [LICENSE](LICENSE) for more info.
